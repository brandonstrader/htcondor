@echo off
set SHARE=%1
whoami > whoami.txt
whoami /upn >> whoami.txt 2>&1
hostname > hostname.txt
type "%SHARE%\health-probe\readme.txt" > share_read_test.txt
echo %COMPUTERNAME% %USERNAME% %DATE% %TIME% > "%SHARE%\health-probe\writes\%COMPUTERNAME%-%RANDOM%.txt"
