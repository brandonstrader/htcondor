@echo off
whoami > whoami.txt
whoami /upn >> whoami.txt 2>&1
hostname > hostname.txt
set > env.txt
