Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function New-PhaseResult {
    param([string]$Name)
    [ordered]@{
        phase = $Name
        timestamp = (Get-Date).ToString('s')
        host = $env:COMPUTERNAME
        fqdn = try { [System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName } catch { $env:COMPUTERNAME }
        whoami = (whoami)
        upn = try { (whoami /upn 2>$null) } catch { $null }
        items = @()
    }
}

function Invoke-CondorCommand {
    param(
        [Parameter(Mandatory=$true)][string]$Command,
        [string]$Category = 'command'
    )
    $out = cmd /c $Command 2>&1
    [pscustomobject]@{
        category = $Category
        command = $Command
        exit_code = $LASTEXITCODE
        output = @($out)
    }
}

function Add-PhaseItem {
    param(
        [hashtable]$Phase,
        [Parameter(Mandatory=$true)]$Item
    )
    $Phase.items += $Item
}

function Save-PhaseResult {
    param(
        [hashtable]$Phase,
        [Parameter(Mandatory=$true)][string]$Path
    )
    $Phase | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $Path
}

function Get-CondorMacroValue {
    param([Parameter(Mandatory=$true)][string]$Macro)
    $r = Invoke-CondorCommand -Command "condor_config_val $Macro"
    if ($r.exit_code -ne 0) { return $null }
    (($r.output -join "`n").Trim())
}

function Get-CondorMacroVerbose {
    param([Parameter(Mandatory=$true)][string]$Macro)
    Invoke-CondorCommand -Command "condor_config_val -v $Macro" -Category 'config'
}

function Ensure-Directory {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function New-SubmitFile {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string[]]$Lines
    )
    $Lines | Set-Content -Encoding ASCII $Path
}

function Wait-CondorJobTerminal {
    param(
        [Parameter(Mandatory=$true)][string]$JobId,
        [int]$TimeoutSeconds = 120,
        [int]$PollSeconds = 5
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        $r = Invoke-CondorCommand -Command "condor_q $JobId -af JobStatus HoldReason ExitCode RemoteHost"
        $text = ($r.output -join "`n").Trim()
        if ($r.exit_code -ne 0 -or [string]::IsNullOrWhiteSpace($text)) {
            # likely left queue; check history
            $h = Invoke-CondorCommand -Command "condor_history $JobId -af JobStatus ExitCode HoldReason RemoteHost"
            return [pscustomobject]@{ live=$false; q=$r; history=$h }
        }
        $fields = $text -split '\s+', 4
        if ($fields.Length -ge 1) {
            $status = [int]$fields[0]
            if ($status -in 4,5,6,7) {
                return [pscustomobject]@{ live=$true; q=$r }
            }
        }
        Start-Sleep -Seconds $PollSeconds
    } while ((Get-Date) -lt $deadline)

    return [pscustomobject]@{ timeout=$true; q=(Invoke-CondorCommand -Command "condor_q $JobId -long") }
}

function Get-SubmittedJobId {
    param([Parameter(Mandatory=$true)]$SubmitResult)
    $text = ($SubmitResult.output -join "`n")
    $m = [regex]::Match($text, 'submitted to cluster\s+(\d+)')
    if ($m.Success) { return "$($m.Groups[1].Value).0" }
    return $null
}
