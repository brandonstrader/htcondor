param(
    [Parameter(Mandatory=$true)][string]$OutFile,
    [Parameter(Mandatory=$true)][string]$Role
)
. "$PSScriptRoot\..\lib\CondorHealth.Common.ps1"

$phase = New-PhaseResult -Name '01-baseline'
Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand 'condor_version' 'version')
Add-PhaseItem -Phase $phase -Item ([pscustomobject]@{
    category='identity'; command='whoami'; exit_code=0; output=@((whoami), (whoami /upn 2>$null))
})
Add-PhaseItem -Phase $phase -Item ([pscustomobject]@{
    category='service'; command='Get-Service'; exit_code=0;
    output=@((Get-Service | Where-Object { $_.Name -like 'Condor*' -or $_.DisplayName -like '*Condor*' } | Format-Table -AutoSize | Out-String))
})
Add-PhaseItem -Phase $phase -Item ([pscustomobject]@{
    category='process'; command='Get-Process'; exit_code=0;
    output=@((Get-Process | Where-Object { $_.ProcessName -like 'condor*' } | Select-Object ProcessName,Id,Path | Format-Table -AutoSize | Out-String))
})
foreach ($m in 'DAEMON_LIST','CONDOR_HOST','COLLECTOR_HOST','CREDD_HOST','UID_DOMAIN','FILESYSTEM_DOMAIN','STARTER_ALLOW_RUNAS_OWNER','LOG','SPOOL','EXECUTE') {
    Add-PhaseItem -Phase $phase -Item (Get-CondorMacroVerbose $m)
}
$phase.role = $Role
Save-PhaseResult -Phase $phase -Path $OutFile
