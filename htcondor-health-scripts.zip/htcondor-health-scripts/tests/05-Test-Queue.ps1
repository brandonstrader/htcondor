param(
    [Parameter(Mandatory=$true)][string]$OutFile,
    [string]$JobId
)
. "$PSScriptRoot\..\lib\CondorHealth.Common.ps1"

$phase = New-PhaseResult -Name '05-queue'
$cmds = @(
    'condor_q',
    'condor_q -totals',
    'condor_status -schedd',
    'condor_status -startd',
    'condor_who -quick'
)
foreach ($c in $cmds) {
    Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command $c -Category 'queue')
}
if ($JobId) {
    Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command "condor_q -better-analyze $JobId" -Category 'queue')
    Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command "condor_q $JobId -long" -Category 'queue')
}
Save-PhaseResult -Phase $phase -Path $OutFile
