param(
    [Parameter(Mandatory=$true)][string]$OutDir,
    [Parameter(Mandatory=$true)][string]$SharePath,
    [Parameter(Mandatory=$true)][string]$OutFile,
    [int]$TimeoutSeconds = 180
)
. "$PSScriptRoot\..\lib\CondorHealth.Common.ps1"
Ensure-Directory -Path $OutDir
$phase = New-PhaseResult -Name '07-runasowner'

$payloadDir = Join-Path $PSScriptRoot '..\payloads\windows'
Copy-Item -LiteralPath (Join-Path $payloadDir 'share-readwrite.cmd') -Destination $OutDir -Force
$submitFile = Join-Path $OutDir 'runasowner.submit'
New-SubmitFile -Path $submitFile -Lines @(
    'universe = vanilla',
    'executable = share-readwrite.cmd',
    "arguments = $SharePath",
    'transfer_input_files = share-readwrite.cmd',
    'should_transfer_files = YES',
    'when_to_transfer_output = ON_EXIT',
    'requirements = (OpSys == "WINDOWS")',
    'run_as_owner = True',
    'output = ro.out',
    'error = ro.err',
    'log = ro.log',
    'queue'
)

Push-Location $OutDir
try {
    Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command 'condor_store_cred query' -Category 'run_as_owner')
    Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command 'condor_store_cred query -c' -Category 'run_as_owner')
    $submit = Invoke-CondorCommand -Command "condor_submit $(Split-Path -Leaf $submitFile)" -Category 'run_as_owner'
    Add-PhaseItem -Phase $phase -Item $submit
    $jobId = Get-SubmittedJobId -SubmitResult $submit
    if ($jobId) {
        $wait = Wait-CondorJobTerminal -JobId $jobId -TimeoutSeconds $TimeoutSeconds
        Add-PhaseItem -Phase $phase -Item ([pscustomobject]@{ category='run_as_owner'; command="wait_job $jobId"; exit_code=0; output=@(($wait | ConvertTo-Json -Depth 6)) })
        Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command "condor_q -better-analyze $jobId" -Category 'run_as_owner')
        Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command "condor_history $jobId -long" -Category 'run_as_owner')
    }
}
finally {
    Pop-Location
}
Save-PhaseResult -Phase $phase -Path $OutFile
