param(
    [Parameter(Mandatory=$true)][string]$OutFile
)
. "$PSScriptRoot\..\lib\CondorHealth.Common.ps1"

$phase = New-PhaseResult -Name '02-config'
$macros = @(
    'UID_DOMAIN','CREDD_HOST','CONDOR_HOST','SEC_DAEMON_AUTHENTICATION','SEC_DAEMON_AUTHENTICATION_METHODS',
    'SEC_DAEMON_INTEGRITY','ALLOW_DAEMON','CREDD.ALLOW_DAEMON','ALLOW_WRITE','ALLOW_ADMINISTRATOR',
    'SEC_CONFIG_AUTHENTICATION','SEC_CONFIG_ENCRYPTION','SEC_CONFIG_INTEGRITY','QUEUE_SUPER_USERS'
)
foreach ($m in $macros) {
    Add-PhaseItem -Phase $phase -Item (Get-CondorMacroVerbose $m)
}

$uid = Get-CondorMacroValue 'UID_DOMAIN'
$fqdn = try { [System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName } catch { $env:COMPUTERNAME }
$phase.items += [pscustomobject]@{
    category='derived'
    command='uid_domain_vs_fqdn'
    exit_code=0
    output=@("UID_DOMAIN=$uid","FQDN=$fqdn", if ($uid -and $fqdn.ToLower().EndsWith($uid.ToLower())) { 'MATCH_OK' } else { 'MISMATCH_OR_UNKNOWN' })
}

Save-PhaseResult -Phase $phase -Path $OutFile
