param(
    [Parameter(Mandatory=$true)][string]$Machine,
    [Parameter(Mandatory=$true)][string]$OutDir,
    [Parameter(Mandatory=$true)][string]$OutFile
)
. "$PSScriptRoot\..\lib\CondorHealth.Common.ps1"
Ensure-Directory -Path $OutDir
$phase = New-PhaseResult -Name '08-collect-logs'
$targets = @('MASTER','SCHEDD','STARTD','CREDD','COLLECTOR','NEGOTIATOR')
foreach ($t in $targets) {
    $dest = Join-Path $OutDir "$Machine-$t.log.txt"
    $r = Invoke-CondorCommand -Command "condor_fetchlog $Machine $t" -Category 'logs'
    if ($r.exit_code -eq 0) {
        ($r.output -join "`r`n") | Set-Content -Encoding UTF8 $dest
    }
    Add-PhaseItem -Phase $phase -Item $r
}
Save-PhaseResult -Phase $phase -Path $OutFile
