param(
    [Parameter(Mandatory=$true)][string]$PoolHost,
    [Parameter(Mandatory=$true)][string]$OutFile
)
. "$PSScriptRoot\..\lib\CondorHealth.Common.ps1"

$phase = New-PhaseResult -Name '04-credd'
$cmds = @(
    'condor_store_cred query',
    'condor_store_cred query -c',
    "condor_status -pool $PoolHost -af Name OpSys LocalCredd",
    "condor_status -pool $PoolHost -f \"%s`t\" Name -f \"%s`n\" ifThenElse(isUndefined(LocalCredd),\"UNDEF\",LocalCredd)"
)
foreach ($c in $cmds) {
    Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command $c -Category 'credd')
}
Save-PhaseResult -Phase $phase -Path $OutFile
