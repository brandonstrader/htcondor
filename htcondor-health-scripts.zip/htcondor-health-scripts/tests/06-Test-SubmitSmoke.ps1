param(
    [Parameter(Mandatory=$true)][string]$OutDir,
    [Parameter(Mandatory=$true)][ValidateSet('WINDOWS','LINUX')][string]$TargetOS,
    [Parameter(Mandatory=$true)][string]$OutFile,
    [int]$TimeoutSeconds = 120
)
. "$PSScriptRoot\..\lib\CondorHealth.Common.ps1"
Ensure-Directory -Path $OutDir
$phase = New-PhaseResult -Name '06-submit-smoke'

$payloadDir = Join-Path $PSScriptRoot '..\payloads\windows'
$submitFile = Join-Path $OutDir "smoke-$TargetOS.submit"
if ($TargetOS -eq 'WINDOWS') {
    Copy-Item -LiteralPath (Join-Path $payloadDir 'whoami.cmd') -Destination $OutDir -Force
    New-SubmitFile -Path $submitFile -Lines @(
        'universe = vanilla',
        'executable = whoami.cmd',
        'transfer_input_files = whoami.cmd',
        'should_transfer_files = YES',
        'when_to_transfer_output = ON_EXIT',
        'requirements = (OpSys == "WINDOWS")',
        'run_as_owner = False',
        'output = smoke.out',
        'error = smoke.err',
        'log = smoke.log',
        'queue'
    )
} else {
    New-SubmitFile -Path $submitFile -Lines @(
        'universe = vanilla',
        'executable = whoami.sh',
        'transfer_input_files = whoami.sh',
        'should_transfer_files = YES',
        'when_to_transfer_output = ON_EXIT',
        'requirements = (OpSys == "LINUX")',
        'output = smoke.out',
        'error = smoke.err',
        'log = smoke.log',
        'queue'
    )
}

Push-Location $OutDir
try {
    $submit = Invoke-CondorCommand -Command "condor_submit $(Split-Path -Leaf $submitFile)" -Category 'submit'
    Add-PhaseItem -Phase $phase -Item $submit
    $jobId = Get-SubmittedJobId -SubmitResult $submit
    if ($jobId) {
        $wait = Wait-CondorJobTerminal -JobId $jobId -TimeoutSeconds $TimeoutSeconds
        Add-PhaseItem -Phase $phase -Item ([pscustomobject]@{ category='submit'; command="wait_job $jobId"; exit_code=0; output=@(($wait | ConvertTo-Json -Depth 6)) })
        Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command "condor_q -better-analyze $jobId" -Category 'submit')
        Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command "condor_history $jobId -long" -Category 'submit')
    }
}
finally {
    Pop-Location
}
Save-PhaseResult -Phase $phase -Path $OutFile
