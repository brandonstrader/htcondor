param(
    [Parameter(Mandatory=$true)][string]$PoolHost,
    [Parameter(Mandatory=$true)][string]$CreddHost,
    [Parameter(Mandatory=$true)][string]$OutFile
)
. "$PSScriptRoot\..\lib\CondorHealth.Common.ps1"

$phase = New-PhaseResult -Name '03-security'
$tests = @(
    'condor_ping -debug -type SCHEDD READ',
    'condor_ping -debug -type SCHEDD WRITE',
    'condor_ping -debug -type MASTER ADMINISTRATOR',
    "condor_ping -debug -pool $PoolHost -name $PoolHost -type COLLECTOR READ",
    "condor_ping -debug -pool $PoolHost -name $CreddHost -type CREDD CONFIG",
    "condor_ping -debug -pool $PoolHost -name $CreddHost -type CREDD DAEMON",
    "condor_ping -debug -pool $PoolHost -name $CreddHost -type CREDD READ WRITE ADMINISTRATOR CONFIG DAEMON",
    "condor_ping -debug -pool $PoolHost -name $PoolHost -type NEGOTIATOR READ"
)
foreach ($t in $tests) {
    Add-PhaseItem -Phase $phase -Item (Invoke-CondorCommand -Command $t -Category 'security')
}
Save-PhaseResult -Phase $phase -Path $OutFile
