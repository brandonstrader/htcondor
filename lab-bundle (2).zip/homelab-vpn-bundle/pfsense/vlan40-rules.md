# pfSense — DOWNLOAD VLAN (VLAN 40, 192.168.40.0/24)

Backstop layer only. The netns jail is the primary control; these rules exist
so that a compromise or misconfiguration *of the VM itself* (not the jail)
still can't reach the internet directly, and so violations get logged.

## Interface

* VLAN 40 on the LAN parent, interface `DOWNLOAD`, pfSense address `192.168.40.1/24`.
* svc-download: static `192.168.40.31/24`, gw `192.168.40.1`.
* Proxmox: `vmbr0` VLAN-aware; svc-download NIC tag=40. No new bridge needed.
* DHCP: off (one static host).
* IPv6 on this interface: none / disabled.

## Aliases

| Alias                | Type    | Content                                   |
|----------------------|---------|-------------------------------------------|
| `VPN_ENDPOINTS`      | Host(s) | provider WireGuard endpoint IP(s)         |
| `TRUENAS`            | Host    | 192.168.1.20                              |
| `ADMIN_HOSTS`        | Host(s) | your MBP tailscale/LAN IP, svc-media if it jumps |

## DOWNLOAD interface rules (top to bottom; first match wins)

| # | Action | Proto | Source          | Destination            | Port     | Log | Purpose |
|---|--------|-------|-----------------|------------------------|----------|-----|---------|
| 1 | Pass   | UDP   | 192.168.40.31   | `VPN_ENDPOINTS`        | 51820    | no  | WireGuard handshake (from the VM's init ns) |
| 2 | Pass   | TCP   | 192.168.40.31   | `TRUENAS`              | 2049     | no  | NFSv4 only (v4 = single port; no rpcbind/mountd sprawl) |
| 3 | Block  | TCP/UDP | DOWNLOAD net  | This Firewall (self)   | 53, 853  | yes | Kill DNS recursion via pfSense — the leak both prior designs left open |
| 4 | Pass   | TCP   | 192.168.40.31   | `VPN_ENDPOINTS`        | 443      | no  | OPTIONAL, disabled by default: some providers fall back to TCP/443 |
| 5 | Block  | any   | DOWNLOAD net    | any                    | any      | yes | Default deny; the log line is your tripwire |

Inbound admin access (LAN -> VLAN40) is governed on the **LAN** interface:
allow `ADMIN_HOSTS` -> 192.168.40.31 TCP {22, 8080, 5076}. Nothing else.

## Patch-window handling

Rule 5 also blocks `dnf`/registry traffic from the VM host (init ns), which is
correct 99% of the time. Two options, pick one:

* **Toggle**: keep a disabled rule `Pass TCP 192.168.40.31 -> any:443` and
  enable it only during patch windows. Cleanest audit story.
* **Standing**: enable it permanently. Pragmatic; residual risk is that a
  container escape to the host gains 443 egress. Given rule 5's logging you'd
  at least see anything *else*.

(Alternative if you run a local mirror/proxy for your RHEL fleet habits:
point dnf at it and keep rule 5 absolute.)

## Validation

```
# from svc-download host (init ns):
curl -4 --max-time 5 https://ifconfig.me        # -> fails/timeouts (rule 5) unless patch rule enabled
dig @192.168.40.1 example.com                   # -> refused/timeout (rule 3)
mount | grep 192.168.1.20                       # -> NFS mounted (rule 2)

# from inside the jail:
ip netns exec vpn curl -4 https://ifconfig.me   # -> provider IP (via wg0; handshake used rule 1)

# pfSense: Status > System Logs > Firewall, filter DOWNLOAD —
# steady state should show zero rule-5 hits from 192.168.40.31.
```

## Rollback

Disable rules 3 and 5 (leave logging rules in place if you want visibility
without enforcement). The VM behaves like any LAN host again. Deleting the
VLAN entirely: revert the VM NIC tag to untagged and remove the interface.
